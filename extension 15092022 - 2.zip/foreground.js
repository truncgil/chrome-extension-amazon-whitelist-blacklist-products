const whiteListUrl = chrome.runtime.getURL('whitelist.txt');
const blackListUrl = chrome.runtime.getURL('blacklist.txt');

let whiteList, blackList;

const selectorList = [
    '.ProductGridItem__itemOuter__5ow0w ProductGridItem__fixed__1w9d4',
    '.s-matching-dir .s-widget-container',
    '.a-carousel-card',
    '.a-list-item',
    '.vvp-item-tile'
];
const gratherThanPrice = 50;

const priceSelectorList = [
    '.a-price-whole'
]

console.log("Whitelist Blacklist Active");
function listAdd(list, type) {
    $.each(list,function(e,productItem){

        $.each(selectorList, function(selectorIndex, selector){
            
            if(productItem.trim()!="") {
                
                var thisSelector = $(selector+":contains('"+productItem.trim()+"')");
             //   thisSelector.parent().find(selector).addClass(type);
                thisSelector.append("<div class='"+type+"'></div>");

                
                
              //  console.log(productItem + "=>" + type);
            }
            
        });
    });
}


$.each(selectorList, function(selectorIndex, selector){
    $(selector).each(function(thisSelectorIndex, thisSelector){

        var thisPrice = $(this).children().find(".a-price-whole").text().replace(",","").trim();
        //console.log(thisPrice);
        
        $(this).addClass("gratherThanButton");
        $(this).append("<button>Check</button>");
        $(this).after().on("click",function(){
            console.log(thisPrice);
            if(thisPrice>gratherThanPrice) {
        
                $(this).addClass("gratherThanButtonTrue");
                
                console.log(thisPrice + " büyüktür " + gratherThanPrice);
            } else {
                    // console.log("küçük");
                    $(this).addClass("gratherThanButtonFalse");
        
            }
            
        });
        
    });
});






$.get(whiteListUrl, function(d){
    whiteList = d.split('\r\n')
    listAdd(whiteList,"whitelist");
});

$.get(blackListUrl, function(d){
    blackList = d.split('\r\n')
    listAdd(blackList,"blacklist");

});


